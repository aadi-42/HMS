package com.cg.hms.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.AdminServiceImpl;
import com.cg.hms.service.BookingServiceImpl;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.IBookingService;
import com.cg.hms.service.IHotelService;
import com.cg.hms.service.IRoomService;
import com.cg.hms.service.RoomServiceImpl;

public class AdminConsole {

	private String currentUser;
	private IHotelService hotelService;
	private IBookingService bookingService;
	private IRoomService roomService;
	private IAdminService adminService = new AdminServiceImpl();
	private Scanner scan = new Scanner(System.in);

	public AdminConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() throws HMSException {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		System.out.println("Welcome " + currentUser);

		int choice = 0;

		while (choice != 9) {

			System.out
					.println("[1]Show Hotels [2]Add Hotel [3]Delete Hotel [4] Modify Hotel \n"
							+ "[5] Show Rooms"
							+ "[6] Add Rooms [7] Delete Rooms [8] Modify Rooms \n"
							+ "[9] Username [10] Booking Details [11]LogOutt");
			System.out.print("Choice> ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				showHotel();
				break;

			case 2:
				addHotel();
				break;

			case 3:
				deleteHotel();
				break;

			case 4:
				modifyHotel();
				break;

			case 5:
				showRooms();
				break;

			case 6:
				addRooms();
				break;

			case 7:
				deleteRoom();
				break;

			case 8:
				modifyRoom();
				break;
				
			case 9:
				getUserList();
				break;
				
			case 10:
				getBookingdets();
				break;
				
			case 11:
				System.out.println("Logged Out");;
				break;
			}
		}
	}

	public void showHotel() {
		System.out.println("List of Hotels");
		List<Hotel> hotels;
		try {
			hotels = hotelService.listHotels();

			if (hotels != null) {

				String leftAlignFormat = "| %-15s | %-15s | %-15s | %-15s | %-15s | %-8s |%n";

				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");
				System.out
						.format("| Hotel Id        | Hotel Name      | City            | Description     | Avg rate/night  | Rating   |%n");
				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");
				for (Hotel hotel : hotels) {
					System.out.format(leftAlignFormat, hotel.getHotelId(),
							hotel.getHotelName(), hotel.getCity(),
							hotel.getDescription(), hotel.getAvgRatePerNight(),
							hotel.getRating());
				}
				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");

			} else {
				System.out.println("No Records Found!");
			}
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

	public void addHotel() throws HMSException {
		// instantiate hotel and add hotel
		Hotel hotel = new Hotel();
		String hotelName, city, desc, rating, address, phone01, phone02, email, fax;
		int hotelId;
		double avgPerNight;

		try {
			System.out.println("Enter Hotel ID (1001)");
			hotelId = scan.nextInt();

			System.out.println("Enter Hotel Name (Oberoi)");
			hotelName = scan.next();

			System.out.println("Enter Hotel city (Mumbai)");
			city = scan.next();

			System.out.println("Enter Hotel description (Aukat se bahar)");
			desc = scan.next();

			System.out.println("Enter Hotel rating (5)");
			rating = scan.next();
			//rating += "★";

			System.out.println("Enter Hotel rate per night (9000)");
			avgPerNight = scan.nextDouble();

			System.out.println("Enter Hotel address (Leopold Cafe)");
			address = scan.next();
			System.out.println("Enter Hotel Phone (7985425421)");
			phone01 = scan.next();
			System.out
					.println("Enter Hotel alternative phone no. (9874521456)");
			phone02 = scan.next();
			System.out.println("Enter Hotel email (oberoi@nocce.com)");
			email = scan.next();
			System.out.println("Enter Hotel alternative fax (89541256)");
			fax = scan.next();

			hotel.setHotelName(hotelName);
			hotel.setHotelId(hotelId);
			hotel.setCity(city);
			hotel.setDescription(desc);
			hotel.setRating(rating);
			hotel.setAddress(address);
			hotel.setPhoneNo1(phone01);
			hotel.setPhoneNo2(phone02);
			hotel.setEmail(email);
			hotel.setFax(fax);
			hotel.setAvgRatePerNight(avgPerNight); // to be set after adding
													// rooms only
		} catch (InputMismatchException e) {
			throw new HMSException("\nPlease Enter Digits (0-9) only.");
		}

		try {
			System.out.println("Hotel added: " + adminService.addHotel(hotel));
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

	private void showRooms() {
		int hotelid;

		List<Room> roomList;
		hotelService = new HotelServiceImpl();

		showHotel();
		System.out.println("Enter Hotel ID");

		try {
			hotelid = Integer.parseInt(scan.next());
			roomList = hotelService.listRooms(hotelid);
			if (roomList.isEmpty()) {
				System.out.println("Hotel does not exist"
						+ "\nSelect Hotel ID present in the above table");
				return;
			} else {
				if (roomList != null) {

					String leftAlignFormat = "| %-15s | %-15s | %-15s | %-15s | %-15s |%n";

					System.out
							.format("+-----------------+-----------------+-----------------+-----------------+-----------------+%n");
					System.out
							.format("|     Room Id     | Room No.        | Room Type       | Price per night | Availablitiy    |%n");
					System.out
							.format("+-----------------+-----------------+-----------------+-----------------+-----------------+%n");
					for (Room room : roomList) {
						System.out.format(leftAlignFormat, room.getRoomId(),
								room.getRoomNo(), room.getRoomType(),
								room.getPerNightPrice(), room.getAvailable());
					}
					System.out
							.format("+-----------------+-----------------+-----------------+-----------------+-----------------+%n");

				} else {
					System.out.println("No Records Found!");
				}
			}
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.err.println("Invalid Entry." + "\nEnter digits 0-9 only");
		}
	}

	private void addRooms() {

		String roomType;

		int hotelId, roomId, roomNo, perNightPrice;
		Room room = new Room();
		int rType;
		showHotel();
		System.out.println("Enter Hotel ID");

		List<Room> roomList;
		try {
			hotelId = Integer.parseInt(scan.next());
			roomList = hotelService.listRooms(hotelId);
			if (roomList.isEmpty()) {
				System.out.println("Hotel does not exist"
						+ "\nSelect Hotel ID present in the above table");
				return;
			}
			System.out.println("Enter Room ID");
			roomId = Integer.parseInt(scan.next());
			System.out.println("Room type [1] AC [2] Non-AC [3] Delux AC ");
			rType = Integer.parseInt(scan.next());
			if (rType == 1)
				roomType = "AC";
			else if (rType == 1)
				roomType = "Non-AC";
			else
				roomType = "Delux AC";
			System.out.println("Enter price per night");
			perNightPrice = Integer.parseInt(scan.next());
			System.out.println("Enter room no ");
			roomNo = Integer.parseInt(scan.next());

			room.setAvailable("Yes");
			room.setHotelId(hotelId);
			room.setPerNightPrice(perNightPrice);
			room.setRoomNo(roomNo);
			room.setRoomId(roomId);
			room.setRoomType(roomType);

			System.out.println("Room added " + adminService.addRoom(room));

		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.err.println("Invalid Entry." + "\nEnter digits 0-9 only");
		}
	}

	private void deleteRoom() {
		showRooms();
		System.out.println("Enter Room ID to be deleted");

		try {
			int roomid = Integer.parseInt(scan.next());
			bookingService = new BookingServiceImpl();
			List<Booking> bookList = bookingService
					.listBookingDetailsByRoomid(roomid);
			if (!bookList.isEmpty()) {
				System.out
						.println("Room is in service, cannot be deleted right now. Try again later!");
			} else
				System.out.println("Room has been deleted "
						+ adminService.deleteRoom(roomid));
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.err.println("Invalid Entry." + "\nEnter digits 0-9 only");
		}
	}

	private void modifyRoom() {
		int modify, roomId;
		List<Room> roomList;

		// hotelid;
		/*
		 * Ask hotelid, check if hotelid exists. Ask roomId check if roomid
		 * exists, then modify that room.
		 */
		showRooms();
		try {
			System.out.println("Which Room ID do you want to modify? ");
			roomId = Integer.parseInt(scan.next());
			roomList = hotelService.listRooms(roomId);
			if (roomList.isEmpty()) {
				System.out.println("Room does not exist"
						+ "\nSelect Room ID present in the above table");
				return;
			}
			// check for validation
			System.out
					.println("Choose following options to modify\n [1] Availability [2] Cost per night stay");
			modify = Integer.parseInt(scan.next());

			if (modify == 1) {
				String value;
				int ans;
				System.out
						.println("Change availability to [1] Yes [2] No [3] Reserve");
				ans = scan.nextInt();
				if (ans == 1)
					value = "Yes";
				else if (ans == 2)
					value = "No";
				else
					value = "Reserve";
				adminService.modifyRoomAvailability(roomId, value);
			} else if (modify == 2) {
				int value;
				System.out.println("Enter new cost per night stay(number)");
				value = Integer.parseInt(scan.next());
				adminService.modifyRoomRate(roomId, value);
			}
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (NumberFormatException e) {
			System.err.println("Invalid Entry." + "\nEnter digits 0-9 only");
		}

	}

	public void deleteHotel() throws HMSException {
		showHotel();

		try {
			System.out.println("Enter Hotel id:");
			int id = scan.nextInt();
			int hdeleted = adminService.deleteHotel(id);
			if (hdeleted == 0) {
				System.err.println("Enter Hotel ID present in the above table");
			} else
				System.out.println("Hotel deleted: " + hdeleted);
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (InputMismatchException e) {
			throw new HMSException("\nPlease Enter Digits (0-9) only.");
		}

	}

	public void modifyHotel() throws HMSException {
		showHotel();
		// check for validation
		try {

			System.out.println("Enter the Hotel ID to Modify: ");
			int id = scan.nextInt();
			System.out.println("Provide description: ");
			String desc = scan.next();
			int hModified = adminService.modifyHotel(id, desc);
			if (hModified == 0) {
				System.err.println("Enter Hotel ID present in the above table");
			} else
				System.out.println("Hotel(s) modified: " + hModified);
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		} catch (InputMismatchException e) {
			throw new HMSException("\nPlease Enter Digits (0-9) only.");
		}

	}
public void getUserList(){
		
		List<User> userList;
		roomService = new RoomServiceImpl();
		System.out.println("Hotel Id>:");
		int hcode = scan.nextInt();
		try {
			userList = roomService.listUserName(hcode);
			if (userList == null) {
				System.out.println("UserId does not exist");
				return;
			} else {
				if (userList != null) {


					System.out.println("User Name>:");
					for (User user : userList) {
						System.out.println(user.getUserName());
					}
					}
				}
			}catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}
	public void getBookingdets(){
		roomService = new RoomServiceImpl();
		List<Booking> bookList;
		System.out.println("Hotel Id>:");
		int hcode = scan.nextInt();
		try {
			bookList = roomService.listBookings(hcode);
			if (bookList == null) {
				System.out.println("UserId does not exist");
				return;
			} else {
				if (bookList != null) {


					System.out.println("Hotel ID\tRoom ID\t\tUser ID\t\tBooking ID");
					for (Booking book : bookList) {
						System.out.println(hcode +"\t\t" +book.getRoomId()+"\t\t"+book.getUserId()+"\t\t"+book.getBookingId());
					}
					}
				}
			}catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

}
