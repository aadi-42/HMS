package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class UserDAOImpl implements IUserDAO{
	int status = 0;
	int userId = 0;
	
	@Override
	public User getUserByName(String userName) throws HMSException {
		User user = null;
		try(
				Connection con = DbUtil.getConnection();
				PreparedStatement st = con.prepareStatement(IQueryMapper.GET_USER)
			){
			
			st.setString(1, userName);
			
			ResultSet rs = st.executeQuery();
			if(rs.next()){
				user = new User();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace(); //Remove this later
			throw new HMSException("Unable To Fetch Records");
		}
		return user;
	}

	@Override
	public int addUser(User newUser) throws HMSException {
		// TODO Auto-generated method stub
		try {

			Connection conn = DbUtil.getConnection();
			PreparedStatement st = conn.prepareStatement(IQueryMapper.INSERT_USER);

			st.setString(1, newUser.getPassword());
			st.setString(2, newUser.getRole());
			st.setString(3, newUser.getUserName());
			st.setString(4, newUser.getMobileNo());
			st.setString(5, newUser.getPhoneNo());
			st.setString(6, newUser.getAddress());
			st.setString(7, newUser.getEmail());

			status = st.executeUpdate();

			st = conn.prepareStatement(IQueryMapper.USER_ID_SEQUENCE);
			ResultSet resultSet = st.executeQuery();

			if (resultSet.next()) {
				userId = resultSet.getInt(1);
			}

			if (status == 0) {
				System.err.println("Insertion failed");
				return userId;
			} else {
				return userId;
			}

		} catch (SQLException e) {
			e.printStackTrace(); // Remove this later
			throw new HMSException("Unable To Add Records");
		}
	}

}
