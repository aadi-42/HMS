package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class HotelDAOImpl implements IHotelDAO {

	@Override
	public List<Hotel> listHotels() throws HMSException {
		List<Hotel> hotelList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.LIST_HOTELS);) {

			ResultSet rs = st.executeQuery();

			hotelList = new ArrayList<Hotel>();

			while (rs.next()) {

				Hotel hotel = new Hotel();
				hotel.setHotelId(rs.getInt(1));
				hotel.setCity(rs.getString(2));
				hotel.setHotelName(rs.getString(3));
				hotel.setAddress(rs.getString(4));
				hotel.setDescription(rs.getString(5));
				hotel.setAvgRatePerNight(rs.getInt(6));
				hotel.setPhoneNo1(rs.getString(7));
				hotel.setPhoneNo2(rs.getString(8));
				hotel.setRating(rs.getString(9));
				hotel.setEmail(rs.getString(10));
				hotel.setFax(rs.getString(11));

				hotelList.add(hotel);
			}

			if (hotelList.size() == 0)
				hotelList = null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new HMSException("Unable To Fetch Hotels");
		}
		return hotelList;
	}

	@Override
	public Hotel findHotel(int hcode) throws HMSException {
		Hotel hotel = null;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.FIND_HOTEL);) {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				hotel = new Hotel();
				hotel.setHotelId(rs.getInt(1));
			}

		} catch (SQLException e) {
			throw new HMSException("Unable To Fetch hotel");
		}
		return hotel;

	}

	@Override
	public List<Room> listRooms(int hcode) throws HMSException {

		List<Room> roomList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.FIND_ROOMS);) {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			roomList = new ArrayList<Room>();
			while (rs.next()) {
				Room room = new Room();
				room.setHotelId(rs.getInt(1));
				room.setRoomId(rs.getInt(2));
				room.setRoomNo(rs.getInt(3));
				room.setRoomType(rs.getString(4));
				room.setPerNightPrice(rs.getDouble(5));
				room.setAvailable(rs.getString(6));
				roomList.add(room);
			}

		} catch (SQLException e) {
			throw new HMSException("Unable To Fetch room");
		}
		return roomList;

	}

}
