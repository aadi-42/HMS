package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;

public interface IUserService {

	String getRole(String userName, String password) throws HMSException;
	
	int addUser(User newUser) throws HMSException;

	boolean isValidAddEnquiry(User user) throws HMSException;

	int getUserId(String userName) throws HMSException;
}