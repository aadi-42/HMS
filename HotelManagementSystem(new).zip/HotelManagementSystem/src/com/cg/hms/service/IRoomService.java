package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;

public interface IRoomService {

	List<Room> listRoom(int hcode,String rtype) throws HMSException;

	List<User> listUserName(int hcode) throws HMSException;
	
	List<Booking> listBookings(int hcode) throws HMSException;
}
