package com.cg.hms.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.dao.IAdminDao;
import com.cg.hms.exception.HMSException;

public class AdminServiceImpl implements IAdminService {
	IAdminDao adminDao = new AdminDaoImpl();

	@Override
	public int addHotel(Hotel hotel) throws HMSException {

		if (hotel != null && isValidAddEnquiry(hotel)) {
			return adminDao.addHotel(hotel);
		}
		return 0;
	}

	@Override
	public int modifyHotel(int hotelId, String desc) throws HMSException {

		if (isValidUpdateEnquiry(desc)) {
			return adminDao.modifyHotel(hotelId, desc);
		}
		return 0;
	}

	@Override
	public int deleteHotel(int hotelId) throws HMSException {
		if (isValidDeleteEnquiry(hotelId)) {
			return adminDao.deleteHotel(hotelId);
		}
		return 0;
	}

	@Override
	public int addRoom(Room room) throws HMSException {
		return adminDao.addRoom(room);
	}

	@Override
	public int modifyRoomAvailability(int roomId, String value)
			throws HMSException {
		return adminDao.modifyRoomAvailability(roomId, value);
	}

	@Override
	public int deleteRoom(int roomId) throws HMSException {
		return adminDao.deleteRoom(roomId);
	}

	@Override
	public int modifyRoomRate(int roomId, int value) throws HMSException {
		return adminDao.modifyRoomRate(roomId, value);

	}

	@Override
	public boolean isValidAddEnquiry(Hotel hotel) throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		if (!isValidHotelId(hotel.getHotelId())) {
			validationErrors.add("Hotel ID Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nHotel ID should be of 3 to 5 digits only\n");
		}
		if (!isValidHotelName(hotel.getHotelName())) {
			validationErrors.add("Hotel Name Incorrectly Entered."
					+ "\nPlease Enter Characters (A-Z) only."
					+ "\nHotel Name Should Contain Minimum 3 Characters.\n");
		}
		if (!isValidCity(hotel.getCity())) {
			validationErrors.add("City Name Incorrectly Entered."
					+ "\nPlease Enter Characters (A-Z) only."
					+ "\nCity Name Should Contain Minimum 3 Characters.\n");
		}
		if (!isValidDescription(hotel.getDescription())) {
			validationErrors.add("Description Cannot Be Empty."
					+ "\nShould Contain Minimum 5 Characters.\n");
		}

		if (!isValidRating(hotel.getRating())) {
			validationErrors.add("Rating Cannot Be Empty."
					+ "\nPlease Enter Digits (1-5) only."
					+ "\n 1- Lowest and 5- Highest\n");
		}

		if (!isValidAvgRatePerNight(hotel.getAvgRatePerNight())) {
			validationErrors.add("Rate Cannot Be Empty."
					+ "\nPlease Enter Digits (0-9) only.\n");
		}

		if (!isValidAddress(hotel.getAddress())) {
			validationErrors.add("Address Incorrectly Entered."
					+ "\nAddress Cannot Be Empty."
					+ "\nAddress Should Contain Minimum 7 Characters.\n");
		}

		if (!isValidPhoneNo1(hotel.getPhoneNo1())) {
			validationErrors.add("Phone Number Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits\n");
		}

		if (!isValidPhoneNo2(hotel.getPhoneNo2())) {
			validationErrors.add("Phone Number Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits\n");
		}

		if (!isValidEmail(hotel.getEmail())) {
			validationErrors.add("Email ID Incorrectly Entered."
					+ "\nPlease Enter A Valid Email ID." + "\nEg. abc@xyz.com\n");
		}

		if (!isValidFax(hotel.getFax())) {
			validationErrors.add("Fax Number Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nFax Number Should Be Of 8 digits\n");
		}

		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	// ----------------------------------//
	// 1.HotelManagementSystem-----------------------------------------
	/*******************************************************************************************************
	 * Function Name : isValidAddEnquiry(Hotel hotel) Input Parameters : Hotel
	 * hotel Return Type : Boolean Throws : HMSException Author : Creation Date
	 * : 29/08/2018 Description : Validates the Delete Hotel Query
	 ********************************************************************************************************/

	@Override
	public boolean isValidDeleteEnquiry(int hotelId) throws HMSException {

		if (!isValidHotelId(hotelId)) {
			throw new HMSException("Hotel ID Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only.");
		}

		return true;
	}

	// ----------------------------------//
	// 1.HotelManagementSystem-----------------------------------------
	/*******************************************************************************************************
	 * Function Name : isValidAddEnquiry(Hotel hotel) Input Parameters : Hotel
	 * hotel Return Type : Boolean Throws : HMSException Author : Creation Date
	 * : 29/08/2018 Description : Validates the Update Hotel Query
	 ********************************************************************************************************/

	@Override
	public boolean isValidUpdateEnquiry(String desc)
			throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		if (!isValidDescription(desc)) {
			validationErrors.add("Description Cannot Be Empty."
					+ "\nShould Contain Minimum 3 Characters.");
		}

		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	private boolean isValidFax(String fax) {
		String pattern = "[0-9]{8}";

		if (fax.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidEmail(String email) {

		String ePattern = "^(.+)@(.+)$";

		Pattern pattern = Pattern.compile(ePattern);

		if (pattern.matcher(email).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo2(String phoneNo2) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo2.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo1(String phoneNo1) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo1.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidAddress(String address) {
		String aPattern = "[A-Za-z0-9]{7,}"; // "^[a-zA-Z0-9.-\t\n]";
		Pattern pattern = Pattern.compile(aPattern);

		if (pattern.matcher(address).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidAvgRatePerNight(double avgRatePerNight) {
		String rPattern = "\\d+\\.\\d+"; //"[0-9]{4}";
		Pattern pattern = Pattern.compile(rPattern);
		String rate = Double.toString(avgRatePerNight);
		
//		System.out.println(pattern.matcher(rate).matches());

		if (pattern.matcher(rate).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidRating(String rating) {
		String pattern = "[1-5]{1}";
		
//	2
		
		if (rating.matches(pattern)) {
			return true;
		}
		return false;
	}


	private boolean isValidDescription(String description) {
		String pattern = "[A-Za-z]{3,}";
		if (description.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

	private boolean isValidCity(String city) {
		String pattern = "[A-Za-z]{3,}";
		if (city.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

	private boolean isValidHotelName(String hotelName) {
		String pattern = "[A-Za-z]{3,}";
		if (hotelName.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}

	private boolean isValidHotelId(int hotelId) {
		String pattern = "[0-9]{3,5}";
		
		String hid = Integer.toString(hotelId);

		if (hid.matches(pattern)) {
			return true;
		}
		return false;
	}

}
